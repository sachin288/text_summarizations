import os
import openai

def summarize_text(text, model="gpt-4"):
    """Summarize the given text using GeminiAPI (OpenAI API)."""
    try:
        openai.api_key = os.getenv("OPENAI_API_KEY")

        response = openai.ChatCompletion.create(
            model=model,
            messages=[
                {"role": "system", "content": "You are a helpful assistant for summarizing text."},
                {"role": "user", "content": text}
            ]
        )

        summary = response['choices'][0]['message']['content']
        return summary.strip()

    except Exception as e:
        print(f"Error summarizing text: {e}")
        return None

def main():
    """Main function to run the text summarization script."""
    input_file = "input_text.txt"
    output_file = "summary_text.txt"

    if not os.path.exists(input_file):
        print(f"Input file '{input_file}' not found.")
        return

    with open(input_file, "r", encoding="utf-8") as file:
        text = file.read()

    print("Summarizing text...")
    summary = summarize_text(text)

    if summary:
        with open(output_file, "w", encoding="utf-8") as file:
            file.write(summary)
        print(f"Summary written to '{output_file}'.")
    else:
        print("Failed to generate summary.")

if __name__ == "__main__":
    main()