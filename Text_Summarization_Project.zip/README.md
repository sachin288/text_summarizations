# Text Summarization Project

This project provides a Python-based script to summarize text using the GeminiAPI (OpenAI API).

## Files
- `summarizer.py`: Main script for text summarization.
- `input_text.txt`: Input file where you can place the text to be summarized.
- `summary_text.txt`: Output file where the generated summary is saved.

## Requirements
- Python 3.7 or higher
- OpenAI Python package (`pip install openai`)
- An OpenAI API key set as an environment variable (`OPENAI_API_KEY`).

## Usage
1. Place the text you want to summarize in `input_text.txt`.
2. Run the script: `python summarizer.py`.
3. The summary will be saved in `summary_text.txt`.